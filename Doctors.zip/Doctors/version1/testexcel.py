from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.styles.colors import Color

wb = Workbook()
ws = wb.active

ws.merge_cells('A1:I1')
ws.merge_cells('J1:N1')
ws.merge_cells('O1:U1')
ws.merge_cells('V1:AB1')
ws.merge_cells('AC1:AI1')
ws.merge_cells('AJ1:AP1')
ws.merge_cells('AQ1:AU1')
ws.merge_cells('AV1:AZ1')
ws.merge_cells('BA1:BF1')
ws.merge_cells('BG1:BI1')
ws.merge_cells('BJ1:BM1')


ws['A1'] = "Registration details"
ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws['A1'].fill = PatternFill(start_color='403151', end_color='403151', fill_type="solid")
ws['A1'].font = Font(color="ffffff")
ws['J1'] = "Registration Type - General"
ws['O1'] = "Registration Type - Specialist 1"
ws['V1'] = "Registration Type - Specialist 2"
ws['AC1'] = "Registration Type - Specialist 3"
ws['AJ1'] = "Registration Type - Specialist 4"
ws['AQ1'] = "Registration Type - Provisional"
ws['AV1'] = "Registration Type - Non-practising"
ws['BA1'] = "Registration Type - Limited"
ws['BG1'] = "Personal details"
ws['BJ1'] = "Principal place of practice"

ws['A2'] = ""
ws['B2'] = ""
ws['C2'] = ""
ws['D2'] = ""
ws['E2'] = ""
ws['F2'] = ""
ws['G2'] = ""
ws['H2'] = ""
for col in ws.iter_cols(min_col = 3, max_col = 7):
    for cell in col:
        cell.fill = PatternFill(start_color="401111", end_color="401111", fill_type="solid")
ws['I2'] = ""
ws['J2'] = ""
ws['K2'] = ""
ws['L2'] = ""
ws['M2'] = ""
ws['N2'] = ""
ws['O2'] = ""
ws['P2'] = ""
ws['Q2'] = ""
ws['R2'] = ""
ws['S2'] = ""
ws['T2'] = ""
ws['U2'] = ""
ws['V2'] = ""
ws['W2'] = ""
ws['X2'] = ""
ws['Y2'] = ""
ws['Z2'] = ""

ws['AA2'] = ""
ws['AB2'] = ""
ws['AC2'] = ""
ws['AD2'] = ""
ws['AE2'] = ""
ws['AF2'] = ""
ws['AG2'] = ""
ws['AH2'] = ""
ws['AI2'] = ""
ws['AJ2'] = ""
ws['AK2'] = ""
ws['AL2'] = ""
ws['AM2'] = ""
ws['AN2'] = ""
ws['AO2'] = ""
ws['AP2'] = ""
ws['AQ2'] = ""
ws['AR2'] = ""
ws['AS2'] = ""
ws['AT2'] = ""
ws['AU2'] = ""
ws['AV2'] = ""
ws['AW2'] = ""
ws['AX2'] = ""
ws['AY2'] = ""
ws['AZ2'] = ""

ws['BA2'] = ""
ws['BB2'] = ""
ws['BC2'] = ""
ws['BD2'] = ""
ws['BE2'] = ""
ws['BF2'] = ""
ws['BG2'] = ""
ws['BH2'] = ""
ws['BI2'] = ""
ws['BJ2'] = ""
ws['BK2'] = ""
ws['BL2'] = ""
ws['BM2'] = ""
ws['BN2'] = ""


wb.save("dfkjdf.xlsx")