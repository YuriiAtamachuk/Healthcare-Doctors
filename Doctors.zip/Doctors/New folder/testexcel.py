import pandas as pd
from openpyxl import load_workbook

data = pd.read_csv("australian-postcodes.csv")

data.to_excel("australian-postcodes.xlsx", index=False)

# Load the Excel file

wb = load_workbook('australian-postcodes.xlsx')

# Select the specific worksheet
ws = wb['Sheet1']  # Replace 'Sheet1' with the actual sheet name

# Specify the column number you want to extract (0-based index)
column_number = 0  # For example, 0 corresponds to column A
state_num = 0 

# Extract data from the specified column
suburb = []
state = []
postcode = []
suburborpostcode = []

for row in ws.iter_rows(min_row=2, min_col=column_number+1, max_col=column_number+1):
    for cell in row:
        suburb.append(cell.value)

for row in ws.iter_rows(min_row=2, min_col=column_number+2, max_col=column_number+2):
    for cell in row:
        state.append(cell.value)

for row in ws.iter_rows(min_row=2, min_col=column_number+3, max_col=column_number+3):
    for cell in row:
        postcode.append(cell.value)
state_num = len(state)
# Print the extracted data

for i in range(state_num):
    concatenated_value = suburb[i] + "," + state[i] + "," + str(postcode[i])
    suburborpostcode.append(concatenated_value)


